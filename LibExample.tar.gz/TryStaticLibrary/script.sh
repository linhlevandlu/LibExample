# create static library with c++
g++ -c Calculator.cpp
g++ -c Test.cpp
ar crv libcalc.a Calculator.o
g++ -o Test Test.o libcalc.a -lm
./Test 1005 105

# create a dynamic library with c++
# g++ -I ./inc -fpic -c src/Circle.cpp -o Circle.o
# g++ -shared -o libs/libCircle.so Circle.o
