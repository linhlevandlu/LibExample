/*
 * Rectangle.h
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include "Shape.h"

namespace geometric {

class Rectangle : public Shape{
public:
	double width;
	double height;
	Rectangle();
	virtual ~Rectangle();
	double calcArea();
};

} /* namespace geometric */
#endif /* RECTANGLE_H_ */
