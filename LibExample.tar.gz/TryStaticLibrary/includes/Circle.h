/*
 * Circle.h
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#ifndef CIRCLE_H_
#define CIRCLE_H_

#include <math.h>
#include "Shape.h"

namespace geometric {

class Circle: public Shape {
public:
	double radius;
	Circle();
	virtual ~Circle();
	double calcArea();
};

} /* namespace geometric */
#endif /* CIRCLE_H_ */
