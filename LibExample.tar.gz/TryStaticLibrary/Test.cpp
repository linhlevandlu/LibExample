/*
 * Test.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "includes/Shape.h"
#include "includes/Circle.h"
#include "includes/Rectangle.h"



using namespace std;
using namespace geometric;


//using namespace geometric;

int main(int argc, char* argv[]) {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	Rectangle rect;
	cout <<"Rectangle area: "<< rect.calcArea()<<"\n";

	Circle circle;
	cout << "Circle area: "<<circle.calcArea()<<"\n";

	/*if (argc > 1) {
		Calculator calc;
		double a, b;
		if (argc == 2) {
			string a1 = argv[1];
			a = atof(a1.c_str());
			cout << "Can bac hai: " << calc.calcSqrt(a) << "\n";
		}
		if (argc == 3) {
			string a1 = argv[1];
			a = atof(a1.c_str());

			string b1 = argv[2];
			b=atof(b1.c_str());

			cout << "Can bac hai: " << calc.calcSqrt(a) << "\n";
			cout << "Tong: " << calc.calcSum(a, b) << "\n";
		}
	} else {
		cout << "No parameters input."<<"\n";
	}*/
	return 0;
}

