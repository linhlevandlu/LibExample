/*
 * Shape.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#include "Shape.h"

namespace geometric {

Shape::Shape() {
	// TODO Auto-generated constructor stub

}

Shape::~Shape() {
	// TODO Auto-generated destructor stub
}

} /* namespace geometric */
