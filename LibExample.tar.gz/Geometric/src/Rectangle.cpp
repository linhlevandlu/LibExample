/*
 * Rectangle.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#include "Rectangle.h"

namespace geometric {

Rectangle::Rectangle() {
	width = 10;
	height = 9;
}

Rectangle::~Rectangle() {
	// TODO Auto-generated destructor stub
}
double Rectangle::calcArea(){
	return width * height;
}
} /* namespace geometric */
