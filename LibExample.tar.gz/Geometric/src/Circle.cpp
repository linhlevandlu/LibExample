/*
 * Circle.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#include "Circle.h"

namespace geometric {

Circle::Circle() {
	radius = 5;

}

Circle::~Circle() {
	// TODO Auto-generated destructor stub
}
double Circle::calcArea(){
	return radius * M_PI;
}
} /* namespace geometric */
