//============================================================================
// Name        : Geometric.cpp
// Author      : LE Van Linh
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Rectangle.h"
#include "Circle.h"

using namespace std;
using namespace geometric;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	Rectangle rect;
	cout<< rect.calcArea()<<"\n";
	Circle circle;
	cout<<circle.calcArea()<<"\n";
	return 0;
}
