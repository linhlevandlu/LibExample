/*
 * Shape.h
 *
 *  Created on: Nov 19, 2015
 *      Author: linh
 */

#ifndef SHAPE_H_
#define SHAPE_H_

namespace geometric {

class Shape {
public:
	Shape();
	virtual ~Shape();
	virtual double calcArea() = 0;
};

} /* namespace geometric */
#endif /* SHAPE_H_ */
